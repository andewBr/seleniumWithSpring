create function shipment_upd_version() returns trigger
    language plpgsql
as
$$
begin
    NEW.rec_version = COALESCE(OLD.rec_version, 0) + 1;
    RETURN NEW;
END;
$$;

alter function shipment_upd_version() owner to iplatform;

