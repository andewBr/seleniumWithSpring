create function shipment_ins_version() returns trigger
    language plpgsql
as
$$
begin
    NEW.rec_version = 1;
    RETURN NEW;
END;
$$;

alter function shipment_ins_version() owner to iplatform;

